import org.javagram.TelegramApiBridge;
import org.javagram.response.AuthAuthorization;
import org.javagram.response.AuthCheckedPhone;
import org.javagram.response.AuthSentCode;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Loader {

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        TelegramApiBridge bridge = new TelegramApiBridge("149.154.167.50:443", 553926, "c39d927584a5a285d803ad98f107e4dd");

        //Метод проверки номера
        System.out.println("Please, type your phone number.");
        /*AuthCheckedPhone checkedPhone = bridge.authCheckPhone(reader.readLine().trim());
        System.out.println(checkedPhone.isRegistered());*/

        //Метод отправки кода в приложение Telegram
        AuthSentCode sentCode = bridge.authSendCode(reader.readLine().trim());
        System.out.println("Please, enter code.");
        System.out.println(sentCode.getPhoneCodeHash());

        //Метод авторизации пользователя с возвратом имени и фамилии
        AuthAuthorization signIn = bridge.authSignIn(reader.readLine());
        System.out.println("Welcome to Telegram: " + signIn.getUser());
    }
}
